export default {
  BASE_URL: 'https://swapi.dev/api/'
};
