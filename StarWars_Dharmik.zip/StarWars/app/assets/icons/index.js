const icons = {
  back: require('./leftArrow.png'),
  next: require('./nextArrow.png'),
  search: require('./search.png'),
  cancel: require('./cancel.png')
};

export default icons;
