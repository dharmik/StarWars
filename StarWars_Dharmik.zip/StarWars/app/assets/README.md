### **fonts** folder will contain all the custom fonts and reference will be added in package.json file.

### **images** folder will contain all the large images.

### **icons** folder will have all small icons like add, delete, edit, and other product related icons.
