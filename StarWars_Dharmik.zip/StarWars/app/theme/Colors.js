const colors = {
  transparent: '#00000000',
  white: '#fff',
  black: '#000',
  transparentBlack: '#0008',
  primary: '#191B1F',
  semiPrimary: '#E4CB00',
  lightGray: '#ccc'
};

export default colors;
