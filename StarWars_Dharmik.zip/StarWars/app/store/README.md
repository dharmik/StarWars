### store Folder contains the all the models objects in one object to be dispatch within screens
