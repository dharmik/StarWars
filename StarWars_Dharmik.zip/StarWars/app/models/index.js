import { people } from './People';
import { film } from './Film';
import { species } from './Species';
import { starship } from './Starship';

export { people, film, species, starship };
