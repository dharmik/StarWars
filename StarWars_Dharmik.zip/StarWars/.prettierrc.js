module.exports = {
  singleQuote: true,
  trailingComma: 'none',
};
