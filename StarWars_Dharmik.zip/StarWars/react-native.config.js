module.exports = {
  project: {
    ios: {},
    android: {} // grouped into "project"
  },
  assets: ['./app/assets/fonts']
};
